// 定义一个转换函数
// let changeClass = 'my_webfont';
let changeClass = 'my_test_font';

function getFontNum (num, type) {
    let result = '';
    let fontArr = '';
    if (type === 'my_webfont') {
        fontArr = [
            '&#x51522;',
            '&#x64633;',
            '&#x98977;',
            '&#x87844;',
            '&#x23211;',
            '&#x45466;',
            '&#x61622;',
            '&#x73766;',
            '&#x53588;',
            '&#x20211;'
        ];
    } else {
        fontArr = [
            '&#xffccc;',
            '&#xbbeee;',
            '&#xaaddd;',
            '&#xddeee;',
            '&#xeeaaa;',
            '&#xccddd;',
            '&#xaabbb;',
            '&#xddccc;',
            '&#xddaaa;',
            '&#xffddd;'
        ];
    }
    let nowArr = String(num).split('');
    for (let i=0;i<nowArr.length;i++) {
        if (nowArr[i]<10) {
            for (let l=0;l<fontArr.length;l++) {
                if (nowArr[i]==l) {
                    result += fontArr[l];
                }
            }
        } else {
            result += nowArr[i];
        }
    }

    return result;
}

let htmlArr = [
    {
        'name': 'hhh',
        'age': 16,
        'num': 10086
    },
    {
        'name': 'ggg',
        'age': 18,
        'num': 12286
    },
    {
        'name': 'ttt',
        'age': 14,
        'num': 16686
    },
    {
        'name': 'fff',
        'age': 19,
        'num': 167086
    },
    {
        'name': 'uuu',
        'age': 22,
        'num': 45086
    },
    {
        'name': 'ooo',
        'age': 25,
        'num': 19986
    }
];


let styles = document.createElement('style');
if (changeClass==='my_webfont') {
    styles.innerHTML = "@font-face {"+
        "font-family: 'my_font';"+
        "src: url('fonts/icomoon.eot');"+
        "src:  url('fonts/icomoon.eot') format('embedded-opentype'),"+
        "url('fonts/icomoon.ttf') format('truetype'),"+
        "url('fonts/icomoon.woff') format('woff'),"+
        "url('fonts/icomoon.svg') format('svg');}"+
        ".my_webfont{"+
        "font-family: my_font !important;"+
        "-webkit-font-smoothing: antialiased;"+
        "-moz-osx-font-smoothing: grayscale;}";
} else {
    styles.innerHTML="@font-face {font-family: 'my_font1';"+
        "src: url('fonts/testFont.eot');"+
        "src:  url('fonts/testFont.eot') format('embedded-opentype'),"+
        "url('fonts/testFont.ttf') format('truetype'),"+
        "url('fonts/testFont.woff') format('woff'),"+
        "url('fonts/testFont.svg') format('svg');}"+
        ".my_test_font {"+
        "font-family: my_font1 !important;"+
        "-webkit-font-smoothing: antialiased;"+
        "-moz-osx-font-smoothing: grayscale;}";
}
document.querySelector('head').appendChild(styles);

let html = '<tr><td>名称</td><td>年龄</td><td>数量</td></tr>';
// let head = '<tr><td>名称</td><td>年龄</td><td>数量</td></tr>';
window.onload = function(){
    for (let a=0;a<htmlArr.length;a++) {
        html += '<tr class="'+changeClass+'"><td>'
        +htmlArr[a].name+
        '</td><td>'
        +getFontNum(htmlArr[a].age,changeClass)+
        '</td><td>'
        +getFontNum(htmlArr[a].num,changeClass)+
        '</td></tr>';
    }
    var table = document.createElement('table');
    table.innerHTML = html;
    document.getElementById('body').appendChild(table);
}